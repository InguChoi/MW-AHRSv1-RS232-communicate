# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/life/catkin_ws/src/mw_ahrsv1/msg/imu.msg"
services_str = ""
pkg_name = "mw_ahrsv1"
dependencies_str = "std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "mw_ahrsv1;/home/life/catkin_ws/src/mw_ahrsv1/msg;std_msgs;/opt/ros/kinetic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/kinetic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
