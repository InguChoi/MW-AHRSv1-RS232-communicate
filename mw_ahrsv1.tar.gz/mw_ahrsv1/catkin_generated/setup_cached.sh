#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/life/catkin_ws/src/mw_ahrsv1/devel:$CMAKE_PREFIX_PATH"
export LD_LIBRARY_PATH="/home/life/catkin_ws/src/mw_ahrsv1/devel/lib:$LD_LIBRARY_PATH"
export PATH="/opt/ros/kinetic/bin:/usr/lib/x86_64-linux-gnu/qt4/bin:/usr/bin:/home/life/bin:/home/life/.local/bin:/opt/Qt5.7.0/Tools/QtCreator/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/home/life/tools/arduino-1.8.5"
export PKG_CONFIG_PATH="/home/life/catkin_ws/src/mw_ahrsv1/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export PWD="/home/life/catkin_ws/src/mw_ahrsv1"
export ROSLISP_PACKAGE_DIRECTORIES="/home/life/catkin_ws/src/mw_ahrsv1/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/life/catkin_ws/src/mw_ahrsv1:$ROS_PACKAGE_PATH"