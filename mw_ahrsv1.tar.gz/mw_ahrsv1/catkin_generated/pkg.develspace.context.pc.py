# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/life/catkin_ws/src/mw_ahrsv1/devel/include;/home/life/catkin_ws/src/mw_ahrsv1/include".split(';') if "/home/life/catkin_ws/src/mw_ahrsv1/devel/include;/home/life/catkin_ws/src/mw_ahrsv1/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;std_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lmw_ahrsv1".split(';') if "-lmw_ahrsv1" != "" else []
PROJECT_NAME = "mw_ahrsv1"
PROJECT_SPACE_DIR = "/home/life/catkin_ws/src/mw_ahrsv1/devel"
PROJECT_VERSION = "0.0.0"
